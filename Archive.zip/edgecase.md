error return 258 <br>
example <br>
< test < <br>
ls ||| ls  <br>
bash: syntax error near unexpected token `newline' <br>
bash: syntax error near unexpected token `|' <br>